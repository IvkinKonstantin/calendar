package school.kiddy.crm.entity;

public enum CreatorType {
    CLIENT,
    OPERATOR,
    TEACHER
}